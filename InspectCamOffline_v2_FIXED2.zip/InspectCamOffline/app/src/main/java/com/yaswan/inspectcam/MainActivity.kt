package com.yaswan.inspectcam

import android.Manifest
import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.view.Surface
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

private const val PREFS = "inspectcam"
private const val KEY_CONFIG = "equipment_config_v2"
private const val KEY_OLD_LINE_CONFIG = "line_config"
private const val KEY_WM_TYPE = "wm_type"
private const val KEY_WM_NAME = "wm_name"
private const val KEY_WM_DETAIL = "wm_detail"
private const val KEY_WM_DATE = "wm_date"
private const val KEY_WM_TIME = "wm_time"
private const val FOLDER = "Pictures/InspectCam"

data class EquipmentConfig(val type: String, val name: String, val details: List<String>)

data class WatermarkConfig(
    val type: Boolean = true,
    val name: Boolean = true,
    val detail: Boolean = true,
    val date: Boolean = true,
    val time: Boolean = true
)

class MainActivity : ComponentActivity() {
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { MaterialTheme { InspectCamApp(executor) } } }
    override fun onDestroy() { executor.shutdown(); super.onDestroy() }
}

@Composable
fun InspectCamApp(executor: ExecutorService) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var equipment by remember { mutableStateOf(loadEquipment(context)) }
    var watermark by remember { mutableStateOf(loadWatermark(context)) }
    var selectedType by remember { mutableStateOf(equipment.firstOrNull()?.type ?: "") }
    var selectedName by remember { mutableStateOf(equipment.firstOrNull()?.name ?: "") }
    var selectedDetail by remember { mutableStateOf(equipment.firstOrNull()?.details?.firstOrNull() ?: "") }

    fun refreshSelection(newList: List<EquipmentConfig>) {
        equipment = newList
        if (selectedType !in newList.map { it.type }) selectedType = newList.firstOrNull()?.type ?: ""
        val names = newList.filter { it.type == selectedType }.map { it.name }
        if (selectedName !in names) selectedName = names.firstOrNull() ?: ""
        val details = newList.firstOrNull { it.type == selectedType && it.name == selectedName }?.details.orEmpty()
        if (selectedDetail !in details) selectedDetail = details.firstOrNull() ?: ""
        saveEquipment(context, newList)
    }

    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.CameraAlt, null) }, label = { Text("Kamera") })
            NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.PhotoLibrary, null) }, label = { Text("Galeri") })
            NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Pengaturan") })
        }
    }) { pad ->
        when (tab) {
            0 -> CameraScreen(Modifier.padding(pad), equipment, selectedType, selectedName, selectedDetail,
                onType = { t -> selectedType = t; selectedName = equipment.firstOrNull { it.type == t }?.name ?: ""; selectedDetail = equipment.firstOrNull { it.type == t }?.details?.firstOrNull() ?: "" },
                onName = { n -> selectedName = n; selectedDetail = equipment.firstOrNull { it.type == selectedType && it.name == n }?.details?.firstOrNull() ?: "" },
                onDetail = { selectedDetail = it }, watermark, executor)
            1 -> GalleryScreen(Modifier.padding(pad))
            else -> SettingsScreen(Modifier.padding(pad), equipment, watermark, { refreshSelection(it) }, { watermark = it; saveWatermark(context, it) })
        }
    }
}

@Composable
fun CameraScreen(
    modifier: Modifier,
    equipment: List<EquipmentConfig>, selectedType: String, selectedName: String, selectedDetail: String,
    onType: (String) -> Unit, onName: (String) -> Unit, onDetail: (String) -> Unit,
    watermark: WatermarkConfig, executor: ExecutorService
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var hasPermission by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasPermission = it }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var typeMenu by remember { mutableStateOf(false) }
    var nameMenu by remember { mutableStateOf(false) }
    var detailMenu by remember { mutableStateOf(false) }
    val names = equipment.filter { it.type == selectedType }
    val current = equipment.firstOrNull { it.type == selectedType && it.name == selectedName }
    val details = current?.details.orEmpty()
    LaunchedEffect(Unit) { if (!hasPermission) launcher.launch(Manifest.permission.CAMERA) }

    Box(modifier.fillMaxSize().background(ComposeColor.Black)) {
        if (hasPermission) {
            AndroidView(factory = { ctx ->
                val previewView = PreviewView(ctx)
                val future = ProcessCameraProvider.getInstance(ctx)
                future.addListener({
                    val provider = future.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                    val rotation = previewView.display?.rotation ?: Surface.ROTATION_0
                    val capture = ImageCapture.Builder().setTargetRotation(rotation).setJpegQuality(95).build()
                    imageCapture = capture
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
                }, ContextCompat.getMainExecutor(ctx))
                previewView
            }, modifier = Modifier.fillMaxSize())

            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Pilih objek sebelum foto", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Box {
                            OutlinedButton(onClick = { typeMenu = true }, Modifier.fillMaxWidth()) { Text("JENIS: $selectedType") }
                            DropdownMenu(typeMenu, { typeMenu = false }) {
                                equipment.map { it.type }.distinct().forEach { t -> DropdownMenuItem(text = { Text(t) }, onClick = { onType(t); typeMenu = false }) }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Box {
                            OutlinedButton(onClick = { nameMenu = true }, Modifier.fillMaxWidth(), enabled = names.isNotEmpty()) { Text("OBJEK: $selectedName") }
                            DropdownMenu(nameMenu, { nameMenu = false }) { names.forEach { item -> DropdownMenuItem(text = { Text(item.name) }, onClick = { onName(item.name); nameMenu = false }) } }
                        }
                        Spacer(Modifier.height(6.dp))
                        Box {
                            OutlinedButton(onClick = { detailMenu = true }, Modifier.fillMaxWidth(), enabled = details.isNotEmpty()) { Text("DETAIL: $selectedDetail") }
                            DropdownMenu(detailMenu, { detailMenu = false }) { details.forEach { d -> DropdownMenuItem(text = { Text(d) }, onClick = { onDetail(d); detailMenu = false }) } }
                        }
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(buildPreviewLabel(selectedType, selectedName, selectedDetail), color = ComposeColor.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    IconButton(onClick = {
                        val capture = imageCapture ?: return@IconButton
                        if (selectedType.isBlank() || selectedName.isBlank()) { message = "Pilih objek terlebih dahulu"; return@IconButton }
                        capturePhoto(context, capture, selectedType, selectedName, selectedDetail, watermark, executor) { message = it }
                    }, modifier = Modifier.size(82.dp).border(4.dp, ComposeColor.White, RoundedCornerShape(50))) {
                        Icon(Icons.Default.CameraAlt, null, tint = ComposeColor.White, modifier = Modifier.size(42.dp))
                    }
                    message?.let { Text(it, color = ComposeColor.White, modifier = Modifier.padding(top = 8.dp)) }
                }
            }
        } else {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text("Izin kamera diperlukan", color = ComposeColor.White); Spacer(Modifier.height(12.dp)); Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Izinkan Kamera") }
            }
        }
    }
}

@Composable
fun GalleryScreen(modifier: Modifier) {
    val context = LocalContext.current
    var uris by remember { mutableStateOf(queryPhotos(context)) }
    Column(modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Foto Saya", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            IconButton(onClick = { uris = queryPhotos(context) }) { Icon(Icons.Default.PhotoLibrary, null) }
        }
        Text("Tersimpan lokal • ${uris.size} foto", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(uris) { uri ->
                val bitmap = remember(uri) { loadThumbnail(context.contentResolver, uri) }
                Card(Modifier.fillMaxWidth().height(190.dp)) {
                    if (bitmap != null) AndroidView(factory = { android.widget.ImageView(it).apply { scaleType = android.widget.ImageView.ScaleType.CENTER_CROP; setImageBitmap(bitmap) } }, modifier = Modifier.fillMaxSize()) else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Foto") }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(modifier: Modifier, equipment: List<EquipmentConfig>, watermark: WatermarkConfig, onEquipment: (List<EquipmentConfig>) -> Unit, onWatermark: (WatermarkConfig) -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    var editIndex by remember { mutableStateOf<Int?>(null) }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Pengaturan", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text("Konfigurasi Objek / Equipment", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Buat sendiri Line, Trafo, Couple, Feeder, SVC, Busbar, atau jenis apa pun.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        equipment.forEachIndexed { index, item ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${item.type} • ${item.name}", fontWeight = FontWeight.Bold)
                        Text(if (item.details.isEmpty()) "Tanpa detail" else item.details.joinToString(" • "))
                    }
                    IconButton(onClick = { editIndex = index }) { Icon(Icons.Default.Edit, null) }
                    IconButton(onClick = { if (equipment.size > 1) onEquipment(equipment.toMutableList().also { it.removeAt(index) }) }) { Icon(Icons.Default.Delete, null) }
                }
            }
        }
        Button(onClick = { showAdd = true }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Tambah Objek") }
        Spacer(Modifier.height(24.dp))
        Text("Pengaturan Watermark", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        WatermarkRow("Tampilkan Jenis", watermark.type) { onWatermark(watermark.copy(type = it)) }
        WatermarkRow("Tampilkan Nama Objek", watermark.name) { onWatermark(watermark.copy(name = it)) }
        WatermarkRow("Tampilkan Detail", watermark.detail) { onWatermark(watermark.copy(detail = it)) }
        WatermarkRow("Tampilkan Tanggal", watermark.date) { onWatermark(watermark.copy(date = it)) }
        WatermarkRow("Tampilkan Waktu", watermark.time) { onWatermark(watermark.copy(time = it)) }
        Spacer(Modifier.height(16.dp))
        Text("100% offline • Foto dan konfigurasi disimpan di perangkat.", style = MaterialTheme.typography.bodySmall)
    }
    if (showAdd) EquipmentDialog(null, null, null, onDismiss = { showAdd = false }) { type, name, details -> onEquipment(equipment + EquipmentConfig(type, name, details)); showAdd = false }
    editIndex?.let { idx ->
        val item = equipment[idx]
        EquipmentDialog(item.type, item.name, item.details, onDismiss = { editIndex = null }) { type, name, details ->
            onEquipment(equipment.toMutableList().also { it[idx] = EquipmentConfig(type, name, details) }); editIndex = null
        }
    }
}

@Composable
fun WatermarkRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(checked, onChange) }
}

@Composable
fun EquipmentDialog(initialType: String?, initialName: String?, initialDetails: List<String>?, onDismiss: () -> Unit, onSave: (String, String, List<String>) -> Unit) {
    var type by remember { mutableStateOf(initialType ?: "Line") }
    var name by remember { mutableStateOf(initialName ?: "Line 3") }
    var detailsText by remember { mutableStateOf(initialDetails?.joinToString(", ") ?: "R, S, T") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initialType == null) "Tambah Objek" else "Edit Objek") }, text = {
        Column {
            OutlinedTextField(type, { type = it }, label = { Text("Jenis objek") }, singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Nama objek") }, singleLine = true)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(detailsText, { detailsText = it }, label = { Text("Detail / pilihan (pisahkan koma)") }, singleLine = true)
            Spacer(Modifier.height(6.dp))
            Text("Contoh: R, S, T atau HV, LV atau Main, Reserve", style = MaterialTheme.typography.bodySmall)
        }
    }, confirmButton = {
        Button(onClick = {
            val details = detailsText.split(",").map { it.trim() }.filter { it.isNotBlank() }.distinct()
            if (type.isNotBlank() && name.isNotBlank()) onSave(type.trim(), name.trim(), details)
        }) { Text("Simpan") }
    }, dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Batal") } })
}

private fun buildPreviewLabel(type: String, name: String, detail: String): String = listOf(type, name, detail).filter { it.isNotBlank() }.joinToString(" • ")

private fun capturePhoto(context: Context, capture: ImageCapture, type: String, name: String, detail: String, wm: WatermarkConfig, executor: ExecutorService, onResult: (String) -> Unit) {
    val tempName = "tmp_${System.currentTimeMillis()}.jpg"
    val tempValues = ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, tempName); put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg"); put(MediaStore.Images.Media.RELATIVE_PATH, FOLDER); put(MediaStore.Images.Media.IS_PENDING, 1) }
    val tempUri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, tempValues)
    if (tempUri == null) { onResult("Gagal membuat file"); return }
    val output = ImageCapture.OutputFileOptions.Builder(context.contentResolver, tempUri, tempValues).build()
    capture.takePicture(output, executor, object : ImageCapture.OnImageSavedCallback {
        override fun onError(exc: ImageCaptureException) { context.contentResolver.delete(tempUri, null, null); onResult("Gagal foto: ${exc.message}") }
        override fun onImageSaved(result: ImageCapture.OutputFileResults) {
            executor.execute {
                try {
                    val options = BitmapFactory.Options().apply { inMutable = true; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                    val bitmap = context.contentResolver.openInputStream(tempUri)?.use { BitmapFactory.decodeStream(it, null, options) } ?: error("bitmap null")
                    val finalBitmap = addWatermark(bitmap, type, name, detail, wm)
                    context.contentResolver.openOutputStream(tempUri, "wt")!!.use { finalBitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    val safe = listOf(type, name, detail).filter { it.isNotBlank() }.joinToString("_").replace(Regex("[^A-Za-z0-9_-]"), "_")
                    context.contentResolver.update(tempUri, ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME, "${safe}_${System.currentTimeMillis()}.jpg"); put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
                    if (finalBitmap !== bitmap) bitmap.recycle()
                    finalBitmap.recycle(); onResult("Foto tersimpan")
                } catch (e: Exception) { context.contentResolver.delete(tempUri, null, null); onResult("Gagal watermark: ${e.message}") }
            }
        }
    })
}

private fun addWatermark(source: Bitmap, type: String, name: String, detail: String, wm: WatermarkConfig): Bitmap {
    val out = if (source.isMutable) source else source.copy(Bitmap.Config.ARGB_8888, true)
    val canvas = Canvas(out)
    val pad = (out.width * 0.035f).coerceAtLeast(24f)
    val size = (out.width * 0.032f).coerceIn(28f, 54f)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = size; typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD); setShadowLayer(8f, 2f, 2f, Color.BLACK) }
    val rows = mutableListOf<String>()
    val first = listOfNotNull(if (wm.type) type else null, if (wm.name) name else null, if (wm.detail && detail.isNotBlank()) detail else null).joinToString(" • ")
    if (first.isNotBlank()) rows += first
    val date = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())
    val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    if (wm.date || wm.time) rows += listOfNotNull(if (wm.date) date else null, if (wm.time) time else null).joinToString("  ")
    val lineHeight = size * 1.35f
    val total = rows.size * lineHeight + pad
    canvas.drawRect(0f, out.height - total, out.width.toFloat(), out.height.toFloat(), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(175, 0, 0, 0) })
    rows.forEachIndexed { i, text -> canvas.drawText(text, pad, out.height - total + pad + i * lineHeight + size, paint) }
    return out
}

private fun defaultEquipment(): List<EquipmentConfig> {
    val rst = listOf("R", "S", "T")
    return listOf(
        EquipmentConfig("Line", "Line 1", rst),
        EquipmentConfig("Line", "Line 2", rst),
        EquipmentConfig("Trafo", "Trafo 1", listOf("HV", "LV", "R", "S", "T")),
        EquipmentConfig("Couple", "Couple 1", rst),
        EquipmentConfig("PMT", "PMT 1", rst),
        EquipmentConfig("PMS", "PMS 1", rst),
        EquipmentConfig("CT", "CT 1", rst),
        EquipmentConfig("CVT", "CVT 1", rst),
        EquipmentConfig("LA", "LA 1", rst),
        EquipmentConfig("SVC", "SVC 1", rst),
        EquipmentConfig("Feeder", "Feeder 1", rst),
        EquipmentConfig("Busbar", "Busbar 1", rst)
    )
}

private fun loadEquipment(context: Context): List<EquipmentConfig> {
    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val raw = prefs.getString(KEY_CONFIG, null)
    if (raw != null) return parseEquipment(raw)
    val old = prefs.getString(KEY_OLD_LINE_CONFIG, null)
    if (old != null) runCatching {
        val arr = JSONArray(old)
        val migrated = (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); val p = o.getJSONArray("phases"); EquipmentConfig("Line", o.getString("name"), (0 until p.length()).map { j -> p.getString(j) }) }
        if (migrated.isNotEmpty()) { saveEquipment(context, migrated); return migrated }
    }
    val defaults = defaultEquipment(); saveEquipment(context, defaults); return defaults
}

private fun parseEquipment(raw: String): List<EquipmentConfig> = runCatching {
    val arr = JSONArray(raw); (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); val d = o.optJSONArray("details") ?: JSONArray(); EquipmentConfig(o.getString("type"), o.getString("name"), (0 until d.length()).map { j -> d.getString(j) }) }
}.getOrDefault(defaultEquipment())

private fun saveEquipment(context: Context, list: List<EquipmentConfig>) {
    val arr = JSONArray(); list.forEach { e -> arr.put(JSONObject().apply { put("type", e.type); put("name", e.name); put("details", JSONArray(e.details)) }) }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_CONFIG, arr.toString()).apply()
}

private fun loadWatermark(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).run {
    WatermarkConfig(getBoolean(KEY_WM_TYPE, true), getBoolean(KEY_WM_NAME, true), getBoolean(KEY_WM_DETAIL, true), getBoolean(KEY_WM_DATE, true), getBoolean(KEY_WM_TIME, true))
}
private fun saveWatermark(context: Context, w: WatermarkConfig) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_WM_TYPE, w.type).putBoolean(KEY_WM_NAME, w.name).putBoolean(KEY_WM_DETAIL, w.detail).putBoolean(KEY_WM_DATE, w.date).putBoolean(KEY_WM_TIME, w.time).apply() }

private fun queryPhotos(context: Context): List<Uri> {
    val result = mutableListOf<Uri>(); val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED); val sel = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?"
    context.contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, sel, arrayOf("%$FOLDER%"), "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c -> val id = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID); while (c.moveToNext()) result += Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(id).toString()) }
    return result
}

private fun loadThumbnail(resolver: ContentResolver, uri: Uri): Bitmap? = runCatching {
    val source = android.graphics.ImageDecoder.createSource(resolver, uri)
    android.graphics.ImageDecoder.decodeBitmap(source) { decoder, _, _ -> decoder.setTargetSize(700, 700) }
}.getOrNull()
