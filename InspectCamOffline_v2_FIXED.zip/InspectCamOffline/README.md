# InspectCam Offline v2

Aplikasi Android 100% offline untuk foto inspeksi gardu induk / transmisi,
dengan watermark otomatis: Jenis • Objek • Detail (Phasa) • Tanggal • Waktu.

## Fitur
- Kamera belakang (CameraX)
- Pilih Jenis → Objek → Detail sebelum memotret
- Jenis bawaan: Line, Trafo, Couple, PMT, PMS, CT, CVT, LA, SVC, Feeder, Busbar
- Detail bawaan: R / S / T (Trafo: HV, LV, R, S, T)
- Tambah / edit / hapus equipment custom sendiri
- Watermark dibakar langsung ke file JPEG (bukan overlay layar)
- Galeri foto internal aplikasi
- Penyimpanan lokal: `Pictures/InspectCam` (MediaStore)
- Konfigurasi tersimpan di SharedPreferences (tetap ada setelah aplikasi ditutup)
- Tidak ada permission INTERNET sama sekali

## Cara build APK

### A. Android Studio (paling mudah)
1. `File > Open` → pilih folder ini.
2. Tunggu Gradle Sync selesai (butuh internet sekali saja untuk unduh dependency).
3. `Build > Generate Signed Bundle / APK` **tidak perlu** — keystore sudah dikonfigurasi.
   Cukup: `Build > Build Bundle(s) / APK(s) > Build APK(s)`, pilih varian `release`.
4. APK ada di `app/build/outputs/apk/release/`.

### B. Command line
```bash
./gradlew :app:apkRelease
```
Hasil: `apk/InspectCam_Offline_v2.apk`

### C. Tanpa PC (GitHub Actions)
Upload folder ini ke repo GitHub. Workflow `.github/workflows/build-apk.yml`
akan otomatis membuild dan menghasilkan artifact `InspectCam_Offline_v2.apk`
yang bisa diunduh langsung dari HP.

## Signing
Keystore release sudah disertakan: `app/inspectcam-release.jks`
- storePassword / keyPassword: `inspectcam2026`
- alias: `inspectcam`

APK release langsung ter-signing sehingga bisa di-install di HP
(aktifkan "Install unknown apps" untuk File Manager / Browser).

## Requirement
- JDK 17
- Android Gradle Plugin 8.7.3, Gradle 8.9, Kotlin 2.0.21
- compileSdk 35, minSdk 29 (Android 10 ke atas)
